#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <immintrin.h>
#include "dataset.h"
#include "output.h"
#include "find_frequent_pairs.h"

int
document_has_word(const dataset *ds, size_t doc_index, size_t voc_index)
{
    // Auxiliary function for `find_pairs_naive_bitmaps`

    uint8_t *column_ptr = get_term_bitmap(ds, voc_index);

    if (doc_index >= ds->num_documents)
    {
        printf("error: doc_index out of bounds %ld/%ld\n", doc_index, ds->num_documents);
        exit(1);
    }

    size_t byte_i = doc_index / 8;
    size_t bit_i = 7 - (doc_index % 8);

    uint8_t b = column_ptr[byte_i];
    return ((b >> bit_i) & 0x1) ? 1 : 0;
}

int
find_frequency(int n, uint64_t *a , uint64_t *b, uint64_t *c)
{
    int i = 0 , cnt = 0, n8 = (n/4) * 4;
    for (; i < n8 ; i += 4)
        {
            __m256i x = _mm256_loadu_si256 (( __m256i *)&a[i]);
            __m256i y = _mm256_loadu_si256 (( __m256i *)&b[i]);
            __m256i z = _mm256_and_si256 (x , y);
            //x = _mm256_and_si256 (x , y);
            _mm256_storeu_si256 (( __m256i *)&c[i] , z);
            //printf("abc%llu\n",c[i+1]);
            for (int j=i; j<4+i; ++j)
            {
                for(; c[j] != 0 ; ++cnt)
                c[j] &= (c[j] - 1);
            }
        }
    for (; i < n; ++i)
    {
        c[i] = a[i] & b[i];
        for (; c[i] != 0 ; ++cnt)
        {
            c[i] &= (c[i] - 1);
        }
    }
    return cnt;
}

//int get_bit(int bit_index, uint8_t * bits)
//{int i = bit_index / 8, j = bit_index % 8; return ((bits[i] >> j) & 0x1) == 0x1;}

void
find_pairs_naive_bitmaps(const dataset *ds, output_pairs *op, int threshold)
{
    // This is an example implementation. You don't need to change this, you
    // should implement `find_pairs_quick_*`.

    for (size_t t1 = 0; t1 < ds->vocab_size; ++t1)
    {
        for (size_t t2 = t1+1; t2 < ds->vocab_size; ++t2)
        {
            int count = 0;
            for (size_t d = 0; d < ds->num_documents; ++d)
            {
                int term1_appears_in_doc = document_has_word(ds, d, t1);
                int term2_appears_in_doc = document_has_word(ds, d, t2);
                if (term1_appears_in_doc && term2_appears_in_doc)
                {
                    ++count;
                }
            }
            if (count >= threshold)
                push_output_pair(op, t1, t2, count);
        }
    }
}

void
find_pairs_naive_indexes(const dataset *ds, output_pairs *op, int threshold)
{
    // This is an example implementation. You don't need to change this, you
    // should implement `find_pairs_quick_*`.

    for (size_t t1 = 0; t1 < ds->vocab_size; ++t1)
    {
        const index_list *il1 = get_term_indexes(ds, t1);
        for (size_t t2 = t1+1; t2 < ds->vocab_size; ++t2)
        {
            const index_list *il2 = get_term_indexes(ds, t2);
            
            int count = 0;
            size_t i1 = 0, i2 = 0;
            for (; i1 < il1->len && i2 < il2->len;)
            {
                size_t x1 = il1->indexes[i1], x2 = il2->indexes[i2];
                if (x1 == x2) { ++count; ++i1; ++i2; }
                else if (x1 < x2) { ++i1; }
                else { ++i2; }
            }

            if (count >= threshold)
                push_output_pair(op, t1, t2, count);
        }
    }
}

void
find_pairs_quick_bitmaps(const dataset *ds, output_pairs *op, int threshold)
{
    // TODO implement a quick `find_pairs_quick_bitmaps` procedure using
    // `get_term_bitmap`.
    for (size_t t1=0; t1 < ds->vocab_size; ++t1)
    {
        for (size_t t2=t1+1; t2 < ds->vocab_size; ++t2)
        {
            size_t column_size = get_term_bitmap_len(ds);
            //printf("%zu\n",column_size);
            //size_t nbytes = column_size * ds->vocab_size;
            //printf("%zu\n",nbytes);
            //uint64_t *c = calloc(column_size/8, sizeof(uint64_t));
            uint64_t *c = aligned_malloc(32,column_size/8);
            uint64_t *column_ptr1 = (uint64_t *) get_term_bitmap(ds, t1);
            uint64_t *column_ptr2 = (uint64_t *) get_term_bitmap(ds, t2);
            int cnt = find_frequency(column_size/8, column_ptr1, column_ptr2,c);
            //printf("%d\n",cnt);
            //printf("Printing bits\n");
            //print_bits(c,column_size*8);
            //printf("%u\n",c);
            //for (cnt=0; *c; ++cnt){
            //    *c &= *c - 1;
            //}
            // for (size_t i = 0; i < column_size*8; ++ i)
            //     {
            //         if (get_bit(i, c) == 1) 
            //         {
            //             ++cnt;
            //         }
            //     }
            //printf("%d\n",cnt);
            if (cnt >= threshold)
                push_output_pair(op, t1, t2, cnt);
            aligned_free(c);
            //cnt = ssse3_poptcount3(c, column_size/16);
            //printf("%u\n", cnt);
        }
    }
}

int
binarySearch(uint64_t * arr, size_t l, size_t r, size_t x) 
{
    if (r >= l) 
    { 
        size_t mid = l + (r - l) / 2; 
        if (arr[mid] == x) 
            return mid; 
        if (arr[mid] > x) 
            return binarySearch(arr, l, mid - 1, x); 
        return binarySearch(arr, mid + 1, r, x); 
    } 
    return r+1; 
}

void
find_pairs_quick_indexes(const dataset *ds, output_pairs *op, int threshold)
{
    // TODO implement a quick `find_pairs_quick_indexes` procedure using
    // `get_term_indexes`.
    for (size_t t1 = 0; t1 < ds->vocab_size; ++t1)
    {
        const index_list *il1 = get_term_indexes(ds, t1);
        if (il1->len >= threshold)
        {
            for (size_t t2 = t1+1; t2 < ds->vocab_size; ++t2)
            {
                const index_list *il2 = get_term_indexes(ds, t2);
                if (il2->len >= threshold) // If length of any index list (il1, il2) is less than threshold, it cant be pushed to output
                {
                    int count = 0;
                    size_t i1 = 0, i2 = 0;
                    for (; i1 < il1->len && i2 < il2->len;)
                    {
                        size_t x1 = il1->indexes[i1], x2 = il2->indexes[i2];
                        if (x1 == x2) {++count; ++i1; ++i2;}
                        else if (x1 < x2) {i1 = binarySearch(il1->indexes,i1,il1->len,x2);}
                        else {i2 = binarySearch(il2->indexes,i2,il2->len,x1);}
                    }
                    if (count >= threshold)
                        push_output_pair(op, t1, t2, count); 
                }         
            }
        }    
    }
}
